from distutils.core import setup
import unittest

def test_suites():
    test_loader = unittest.TestLoader()
    test_suite = test_loader.discover('tests', pattern='test_*.py')
    return test_suite

setup(
    name='cityinfo',
    version='0.0.1',
    py_modules=['cityinfo'],
    test_suite='setup.test_suites'
    )
